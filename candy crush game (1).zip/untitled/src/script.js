const board = document.getElementById("game-board");
const scoreDisplay = document.getElementById("score");

const width = 8;
const candyColors = ["red", "blue", "green", "yellow", "orange"];
let candies = [];
let score = 0;

// Create the game board
function createBoard() {
    for (let i = 0; i < width * width; i++) {
        const candy = document.createElement("div");
        candy.setAttribute("draggable", true);
        candy.setAttribute("id", i);
        let randomColor = candyColors[Math.floor(Math.random() * candyColors.length)];
        candy.className = `candy ${randomColor}`;
        board.appendChild(candy);
        candies.push(candy);
    }
}

// Dragging functionality
let colorBeingDragged, colorBeingReplaced, squareIdBeingDragged, squareIdBeingReplaced;

candies.forEach(candy => candy.addEventListener("dragstart", dragStart));
candies.forEach(candy => candy.addEventListener("dragend", dragEnd));
candies.forEach(candy => candy.addEventListener("dragover", dragOver));
candies.forEach(candy => candy.addEventListener("dragenter", dragEnter));
candies.forEach(candy => candy.addEventListener("dragleave", dragLeave));
candies.forEach(candy => candy.addEventListener("drop", dragDrop));

function dragStart() {
    colorBeingDragged = this.className.split(" ")[1];
    squareIdBeingDragged = parseInt(this.id);
}

function dragDrop() {
    colorBeingReplaced = this.className.split(" ")[1];
    squareIdBeingReplaced = parseInt(this.id);

    candies[squareIdBeingDragged].className = `candy ${colorBeingReplaced}`;
    candies[squareIdBeingReplaced].className = `candy ${colorBeingDragged}`;
}

function dragEnd() {
    let validMoves = [
        squareIdBeingDragged - 1,
        squareIdBeingDragged + 1,
        squareIdBeingDragged - width,
        squareIdBeingDragged + width,
    ];

    let isValidMove = validMoves.includes(squareIdBeingReplaced);

    if (squareIdBeingReplaced && isValidMove) {
        squareIdBeingReplaced = null;
    } else if (squareIdBeingReplaced && !isValidMove) {
        candies[squareIdBeingDragged].className = `candy ${colorBeingDragged}`;
        candies[squareIdBeingReplaced].className = `candy ${colorBeingReplaced}`;
    } else candies[squareIdBeingDragged].className = `candy ${colorBeingDragged}`;
}

// Check for matches
function checkRowForThree() {
    for (let i = 0; i < width * width; i++) {
        let row = [i, i + 1, i + 2];
        let decidedColor = candies[i].className.split(" ")[1];
        const isBlank = candies[i].className === "candy";

        if (
            row.every(index => candies[index]?.className.split(" ")[1] === decidedColor && !isBlank)
        ) {
            score += 3;
            row.forEach(index => candies[index].className = "candy");
        }
    }
}

function checkColumnForThree() {
    for (let i = 0; i < width * (width - 2); i++) {
        let column = [i, i + width, i + width * 2];
        let decidedColor = candies[i].className.split(" ")[1];
        const isBlank = candies[i].className === "candy";

        if (
            column.every(index => candies[index]?.className.split(" ")[1] === decidedColor && !isBlank)
        ) {
            score += 3;
            column.forEach(index => candies[index].className = "candy");
        }
    }
}

function moveDown() {
    for (let i = 0; i < width * (width - 1); i++) {
        if (candies[i + width].className === "candy") {
            candies[i + width].className = candies[i].className;
            candies[i].className = "candy";
        }
    }
}

function generateNewCandies() {
    for (let i = 0; i < width; i++) {
        if (candies[i].className === "candy") {
            let randomColor = candyColors[Math.floor(Math.random() * candyColors.length)];
            candies[i].className = `candy ${randomColor}`;
        }
    }
}

// Game loop
function gameLoop() {
    checkRowForThree();
    checkColumnForThree();
    moveDown();
    generateNewCandies();
    scoreDisplay.textContent = score;
    setTimeout(gameLoop, 100);
}

createBoard();
gameLoop();
